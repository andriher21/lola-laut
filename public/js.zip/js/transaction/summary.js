var summary = siteUrl('attendance/employee/printReportSummary/') + id;
var url = siteUrl('attendance/employee/summary/') + id;
var startDate      = moment().startOf('month').format('YYYY-MM-DD');
var endDate 	   = moment().endOf('month').format('YYYY-MM-DD');
var dateRange = {};
var sumPrint
var summaryUrl = summary + '/' + startDate + '/' + endDate;

$('.employee-attendance-data-summary').ready(function() {

    var table = $('#dataTable').dataTable({
        "sDom":"tp",
        "pageLength": 10,
        "pagination":true,
            // Date Sorting
        columnDefs: [
           { type: 'date-eu', targets: ([0])}
         ],
         //// order table onload
        "order": [[ 1, 'desc' ]]
    });
    
    var startdate;
    var enddate;

    $('.data-daterangepicker').daterangepicker({
        ranges: {
            'Today'       : [moment(), moment()],
            'Yesterday'   : [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
            'Last 7 Days' : [moment().subtract(6, 'days'), moment()],
            'Last 30 Days': [moment().subtract(29, 'days'), moment()],
            'This Month'  : [moment().startOf('month'), moment().endOf('month')],
            'Last Month'  : [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')],
        },
        startDate: moment().startOf('month'),
        endDate  : moment().endOf('month'),
    }, function (start, end, label) {
        var labels = $('.data-daterangepicker').html('&nbsp; <i class="fas fa-calendar-alt mr-2"></i> '+label+ '&nbsp;');
        startdate = start.format("YYYY-MM-DD");
        enddate = end.format("YYYY-MM-DD");
    });

    $('.data-daterangepicker').on('apply.daterangepicker', function(ev, picker) {
		startdate = picker.startDate.format('YYYY-MM-DD');
		enddate = picker.endDate.format('YYYY-MM-DD');
		
        $.fn.dataTableExt.afnFiltering.push(
            function( oSettings, aData, iDataIndex ) {
                if(startdate!=undefined){
                    
                    var coldate = aData[0];
                    var date;
                    date = coldate;

                    dateMin = startdate;
                    dateMax = enddate;

                    if ( dateMin == "" && date <= dateMax){
                        return true;
                    }
                    else if ( dateMin =="" && date <= dateMax ){
                        return true;
                    }
                    else if ( dateMin <= date && "" == dateMax ){
                        return true;
                    }
                    else if ( dateMin <= date && date <= dateMax ){
                        return true;
                    }
                    
                    return false;
                }
            }
        );
        table.fnDraw();
        sumPrint = summary + '/' + startdate + '/' + enddate;
        summaryUrl = sumPrint;
    });

    $(".btn-print-summary").click(function() {
        setTimeout(function() {
            $('#print-summary-report').attr('src', summaryUrl);
        }, 50);
    });
});


