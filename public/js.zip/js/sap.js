var otable = $('#dataTable').dataTable({
    "bLengthChange" : false,
     "order": [[2, 'desc']],
    "pageLength": 5
});

var data10 = $('#data10').dataTable({
    "bLengthChange" : false,
    "order": [[4, 'asc']],
});

var data10 = $('#data00').dataTable({
    "bLengthChange" : false,
    "order": [[4, 'asc']],
});

var atlogregio = $('#atlogregio').dataTable({
    "bLengthChange" : false,
    "order": [[8, 'desc']],
});