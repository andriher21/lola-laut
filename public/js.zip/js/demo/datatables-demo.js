// // Call the dataTables jQuery plugin
// $(document).ready(function() {
//   // var otable = $('#dataTable').dataTable({
//   //   "aoColumnDefs": [
//   //     { 'bSortable': false }
//   //  ],
//   //   "bLengthChange" : false,
//   //   "bFilter" : true,
//   //   language: {
//   //     searchPlaceholder: "Search data by employee name"
//   //   }});

//   // $('#searchbox').keyup(function() {
//   //   otable.fnFilter($(this).val());
//   // });

// });
