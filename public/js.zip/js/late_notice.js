window.setTimeout( function() {
    window.location.reload();
  }, 30000);