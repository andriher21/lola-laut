config = {
    enableTime: true,
    // noCalendar: true,
    // dateFormat: "Y-m-d H:i",
    noCalendar: true,
    time_24hr: true
};
flatpickr("#allowed", config);